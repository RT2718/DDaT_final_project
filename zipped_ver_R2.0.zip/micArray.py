import time
import numpy as np
from collections import deque

import keyboard
import pyaudio
import matplotlib.pyplot as plt

import signal_processing
import constants
from robotics import Robot


class MicArray:
    def __init__(self, rate=constants.SAMPLE_RATE, chunk_size=constants.CHUNK_SIZE, robot: Robot = None):
        self.pyaudio_instance = None
        self.stream = None
        self.channels = None
        self.sample_rate = rate
        self.chunk_size = chunk_size
        self.robot = robot

        # plotting state
        self.fig = None
        self.ax_corr = None
        self.ax_polar = None
        self.plot_lines = None
        self.polar_marker = None
        self.polar_trail_line = None
        self._trail = deque(maxlen=40)

    def _select_mic_device_index(self):
        """Pick the ReSpeaker USB Mic Array device index automatically."""
        print("-" * 120)
        print("Available ReSpeaker non-speaker audio devices:")

        max_channels = 0
        max_idx = None
        max_name = ''

        for i in range(self.pyaudio_instance.get_device_count()):
            dev = self.pyaudio_instance.get_device_info_by_index(i)
            name = dev['name']
            if (('ReSpeaker' in name) or ('reSpeaker' in name)) and ('Speakers' not in name):
                in_ch = dev['maxInputChannels']
                print(f'  index={i}, name={name!r}, in_ch={in_ch}')
                if in_ch > max_channels:
                    max_channels = in_ch
                    max_name = name
                    max_idx = i

        if max_idx is None:
            raise Exception("Cannot find ReSpeaker input device.")

        self.channels = max_channels
        print("-" * 120)
        print("Selected device:")
        print(f'  name = {max_name!r}')
        print(f'  channels = {max_channels}')
        return max_idx

    def _setup_plot(self):
        """Two subplots in one figure: cross-correlation viewer + DOA polar plot."""
        plt.ion()
        self.fig = plt.figure(figsize=(12, 5))

        # ---- Left: cross-correlation between mics 0 and 2 (debug / sanity check) ----
        self.ax_corr = self.fig.add_subplot(1, 2, 1)
        times = [i - constants.CORRELATION_WINDOW for i in range(constants.CORRELATION_RANGE)]
        y0 = [0] * constants.CORRELATION_RANGE
        self.plot_lines = [self.ax_corr.plot(times, y0, marker='o')[0]]
        self.ax_corr.set_xlabel('lag [samples]')
        self.ax_corr.set_ylabel('correlation')

        # ---- Right: DOA polar plot ----
        self.ax_polar = self.fig.add_subplot(1, 2, 2, projection='polar')
        self.ax_polar.set_rlim(0, np.pi / 2)
        self.ax_polar.set_rticks([np.pi / 8, np.pi / 4, 3 * np.pi / 8, np.pi / 2])
        self.ax_polar.set_yticklabels(['22.5°', '45°', '67.5°', '90°'])
        self.ax_polar.set_title('DOA   φ (angle)  ·  θ (radius)')

        self.polar_marker, = self.ax_polar.plot([0], [0], 'o', markersize=14, color='red', zorder=5)
        self.polar_trail_line, = self.ax_polar.plot([], [], '-', alpha=0.5, color='steelblue', linewidth=1)

        self.fig.tight_layout()

    def _process_audio_data(self, data):
        """Convert raw bytes into a (n_samples, NUM_CIRCULAR_MICS) array."""
        samples = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        n = samples.shape[0] // self.channels
        frames = samples.reshape((n, self.channels))

        idx = [c for c in constants.RESPEAKER_RAW_MIC_CHANNELS if c < self.channels]
        mics = frames[:, idx].copy()
        for i in range(mics.shape[1]):
            mics[:, i] = signal_processing.center(mics[:, i])
        return mics

    def _calculate_angles(self, samples_by_channel):
        phi, theta_elev, _, _ = signal_processing.estimate_doa(samples_by_channel)
        theta_polar = np.pi / 2 - theta_elev
        return phi, theta_polar

    def _update_visualization(self, samples_by_channel, phi, theta, sim_target=None):
        self._trail.append((phi, theta))
        self.polar_marker.set_data([phi], [theta])
        if len(self._trail) > 1:
            tp, tt = zip(*self._trail)
            self.polar_trail_line.set_data(list(tp), list(tt))

        # Update title. If simulating, show the Ground Truth vs Measured!
        if sim_target:
            t_phi, t_theta = sim_target
            self.ax_polar.set_title(
                f"TARGET: φ={np.rad2deg(t_phi) % 360:5.1f}° θ={np.rad2deg(t_theta):4.1f}°\n"
                f"TRACK : φ={np.rad2deg(phi) % 360:5.1f}° θ={np.rad2deg(theta):4.1f}°"
            )
        else:
            self.ax_polar.set_title(f'DOA   φ={np.rad2deg(phi) % 360:5.1f}°  θ={np.rad2deg(theta):4.1f}°')

        a = samples_by_channel[:, 0]
        b = samples_by_channel[:, 2]
        r = signal_processing.corr(a, b)
        self.plot_lines[0].set_ydata(r)
        self.ax_corr.set_title(f"correlation mics 0 & 2   σ = {signal_processing.sigma(r):.4f}")
        self.ax_corr.relim()
        self.ax_corr.autoscale_view()

        plt.draw()
        plt.pause(0.001)

    # ---------------------------------------------------------
    # NEW SIMULATOR INJECTION
    # ---------------------------------------------------------
    def _generate_synthetic_block(self, phi, theta_elev, noise_level=0.1):
        """Generates a raw, noisy audio block mathematically perfectly delayed for your specific mic array."""
        base_audio = np.random.randn(self.chunk_size).astype(np.float32)
        base_fft = np.fft.rfft(base_audio)
        freqs = np.fft.rfftfreq(self.chunk_size, 1 / self.sample_rate)

        u = np.array([
            np.cos(phi) * np.cos(theta_elev),
            np.sin(phi) * np.cos(theta_elev),
            np.sin(theta_elev)
        ])

        N = constants.NUM_CIRCULAR_MICS
        simulated_mics = np.zeros((self.chunk_size, N), dtype=np.float32)

        R = constants.MIC_ARRAY_RADIUS
        C = constants.SPEED_OF_SOUND

        for m in range(N):
            # Calculate physical coordinate of this specific mic based on constants.py
            angle = constants.MIC_ANGLES[m]
            r_m = np.array([R * np.cos(angle), R * np.sin(angle), 0.0])

            # Apply perfect delay
            tau = -np.dot(r_m, u) / C
            phase_shift = np.exp(-1j * 2 * np.pi * freqs * tau)
            shifted_fft = base_fft * phase_shift

            # Convert to time domain and add noise
            mic_audio = np.fft.irfft(shifted_fft, n=self.chunk_size)
            mic_audio += noise_level * np.random.randn(self.chunk_size)

            # Center the signal just like _process_audio_data does
            simulated_mics[:, m] = signal_processing.center(mic_audio)

        return simulated_mics

    def run(self, simulate=False, trajectory='circle'):
        # --- 1. SETUP PHASE ---
        if not simulate:
            self.pyaudio_instance = pyaudio.PyAudio()
            device_index = self._select_mic_device_index()
            self.stream = self.pyaudio_instance.open(
                format=pyaudio.paInt16, channels=self.channels,
                rate=self.sample_rate, frames_per_buffer=self.chunk_size,
                input=True, input_device_index=device_index,
            )
            print("Starting live audio measurements... (press 'w' to stop)")
        else:
            print("-" * 120)
            print(f"Starting VIRTUAL Simulation Mode (Trajectory: {trajectory})...")
            print("Press 'w' in the terminal to stop.")
            print("-" * 120)

        self._setup_plot()
        frame_count = 0

        # --- 2. EXECUTION LOOP ---
        try:
            while True:
                sim_target = None

                # GRAB DATA (Hardware or Software)
                if not simulate:
                    data = self.stream.read(self.chunk_size, exception_on_overflow=False)
                    mics = self._process_audio_data(data)
                else:
                    # Trajectory Math
                    t = frame_count
                    if trajectory == 'circle':
                        sim_phi = (t / 50.0) * (2 * np.pi) % (2 * np.pi)
                        sim_theta_elev = np.pi / 4  # Constant 45 deg elevation
                    elif trajectory == 'arc':
                        sim_phi = np.pi / 2
                        sim_theta_elev = (np.sin(t / 20) + 1) / 2 * (np.pi / 2)
                    elif trajectory == 'spiral':
                        sim_phi = (t / 20.0) * (2 * np.pi)
                        sim_theta_elev = (np.sin(t / 50) + 1) / 2 * (np.pi / 2)
                    else:  # Static point
                        sim_phi, sim_theta_elev = np.pi / 4, np.pi / 4

                    mics = self._generate_synthetic_block(sim_phi, sim_theta_elev, noise_level=0.1)
                    sim_target = (sim_phi, np.pi / 2 - sim_theta_elev)  # Save for plotting
                    time.sleep(self.chunk_size / self.sample_rate)  # Mimic physical processing delay

                # RUN THE DOA ALGORITHM
                phi, theta = self._calculate_angles(mics)

                if self.robot:
                    self.robot.update(theta, phi)

                self._update_visualization(mics, phi, theta, sim_target=sim_target)

                frame_count += 1
                if keyboard.is_pressed('w'):
                    break
        finally:
            if not simulate:
                self.stream.stop_stream()
                self.stream.close()
                self.pyaudio_instance.terminate()
            plt.pause(2)