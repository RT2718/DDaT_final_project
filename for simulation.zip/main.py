from micArray import MicArray
from robotics import Robot

if __name__ == '__main__':
    # Initialize the robot (if applicable)
    robot = Robot(updateTime=0.03, disable=False)

    # Initialize the microphone array
    mic = MicArray(robot=robot)

    # Run in simulation mode!
    # Change trajectory to 'circle' (phi graph), 'arc' (theta graph), or 'spiral' (both graphs)
    mic.run(simulate=True, trajectory='arc')