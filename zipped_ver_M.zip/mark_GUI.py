import tkinter as tk
from tkinter import ttk, messagebox  # Added messagebox import
import serial
import serial.tools.list_ports
import threading
import time


class PanTiltController:
    def __init__(self, root):
        self.root = root
        self.root.title("Pan/Tilt Stepper Control")
        self.root.geometry("400x450")  # Increased height for new controls
        self.root.configure(bg="#f0f0f0")

        # Serial Connection
        self.ser = None
        self.is_connected = False

        # State tracking (to prevent serial spamming on key hold)
        self.key_states = {
            'Up': False,  # Tilt Up
            'Down': False,  # Tilt Down
            'Left': False,  # Pan Left
            'Right': False  # Pan Right
        }

        self.setup_ui()
        self.scan_ports()

        # Bind keyboard events
        self.root.bind('<KeyPress>', self.handle_keypress)
        self.root.bind('<KeyRelease>', self.handle_keyrelease)

        # Safety: Stop motors if window loses focus
        self.root.bind('<FocusOut>', self.emergency_stop)

    def setup_ui(self):
        # Header
        header = tk.Label(self.root, text="NUCLEO Stepper Controller", font=("Arial", 14, "bold"), bg="#f0f0f0")
        header.pack(pady=10)

        # COM Port Selection
        frame_conn = tk.Frame(self.root, bg="#f0f0f0")
        frame_conn.pack(pady=5)

        tk.Label(frame_conn, text="Port:", bg="#f0f0f0").pack(side=tk.LEFT, padx=5)
        self.port_combo = ttk.Combobox(frame_conn, width=20)
        self.port_combo.pack(side=tk.LEFT, padx=5)

        self.btn_connect = tk.Button(frame_conn, text="Connect", command=self.toggle_connection, bg="#dddddd")
        self.btn_connect.pack(side=tk.LEFT, padx=5)

        # Refresh Button
        tk.Button(frame_conn, text="↻", command=self.scan_ports, width=3).pack(side=tk.LEFT)

        # Controls Visualization
        frame_controls = tk.Frame(self.root, bg="#f0f0f0", bd=2, relief=tk.GROOVE)
        frame_controls.pack(pady=20, padx=20, fill=tk.BOTH, expand=True)

        self.lbl_pan = tk.Label(frame_controls, text="PAN: IDLE", font=("Consolas", 12), fg="grey", bg="#f0f0f0")
        self.lbl_pan.pack(pady=10)

        self.lbl_tilt = tk.Label(frame_controls, text="TILT: IDLE", font=("Consolas", 12), fg="grey", bg="#f0f0f0")
        self.lbl_tilt.pack(pady=10)

        instructions = tk.Label(frame_controls, text="Use Arrow Keys to Move Manually", fg="#666", bg="#f0f0f0")
        instructions.pack(side=tk.BOTTOM, pady=5)

        # --- NEW SECTION: Angle Control ---
        frame_angle = tk.Frame(self.root, bg="#e0e0e0", bd=2, relief=tk.RAISED)
        frame_angle.pack(pady=10, padx=20, fill=tk.X)

        tk.Label(frame_angle, text="Go To Angle (-179° to 180°)", bg="#e0e0e0", font=("Arial", 10, "bold")).pack(pady=5)

        frame_inputs = tk.Frame(frame_angle, bg="#e0e0e0")
        frame_inputs.pack(pady=5)

        self.entry_angle = tk.Entry(frame_inputs, width=10, font=("Arial", 12), justify='center')
        self.entry_angle.pack(side=tk.LEFT, padx=10)
        self.entry_angle.insert(0, "0")  # Default 0

        # Buttons to trigger the move
        tk.Button(frame_inputs, text="Set Pan", command=lambda: self.send_angle('B'), bg="lightblue").pack(side=tk.LEFT,
                                                                                                           padx=5)
        tk.Button(frame_inputs, text="Set Tilt", command=lambda: self.send_angle('A'), bg="lightgreen").pack(
            side=tk.LEFT, padx=5)

    def scan_ports(self):
        ports = serial.tools.list_ports.comports()
        port_list = [port.device for port in ports]
        self.port_combo['values'] = port_list
        if port_list:
            self.port_combo.current(0)

    def toggle_connection(self):
        if not self.is_connected:
            try:
                port = self.port_combo.get()
                self.ser = serial.Serial(port, 115200, timeout=1)
                self.is_connected = True
                self.btn_connect.config(text="Disconnect", bg="#ffcccc")
                print(f"Connected to {port}")
            except Exception as e:
                tk.messagebox.showerror("Connection Error", str(e))
        else:
            self.emergency_stop(None)
            self.ser.close()
            self.is_connected = False
            self.btn_connect.config(text="Connect", bg="#dddddd")

    def send_command(self, axis, value):
        """
        Protocol: <Axis><Value>\n
        P1/T1... for Velocity
        """
        if self.is_connected and self.ser:
            cmd = f"{axis}{value}\n"
            try:
                self.ser.write(cmd.encode('ascii'))
                print(f"Sent: {cmd.strip()}")
            except Exception as e:
                print(f"Serial Error: {e}")
                self.toggle_connection()

    def send_angle(self, axis_char):
        """
        New Function: Reads the entry box, validates angle, sends A<val> or B<val>
        """
        if not self.is_connected:
            tk.messagebox.showwarning("Warning", "Connect to board first!")
            return

        try:
            angle = int(self.entry_angle.get())
            if -179 < angle <= 180:  # Range check
                cmd = f"{axis_char}{angle}\n"
                self.ser.write(cmd.encode('ascii'))
                print(f"Sent Absolute Move: {cmd.strip()}")

                axis_name = "TILT" if axis_char == 'A' else "PAN"
                label = self.lbl_tilt if axis_char == 'A' else self.lbl_pan
                label.config(text=f"{axis_name}: GO TO {angle}°", fg="blue")
            else:
                tk.messagebox.showerror("Error", "Angle must be between -179 and 180")
        except ValueError:
            tk.messagebox.showerror("Error", "Please enter a valid integer number")

    def update_status(self, axis, value):
        # We only update status for manual moves here
        # The Angle move updates its own status in send_angle
        label = self.lbl_pan if axis == 'P' else self.lbl_tilt
        text_axis = "PAN" if axis == 'P' else "TILT"

        if value == 1:
            label.config(text=f"{text_axis}: MOVING (+)", fg="green")
        elif value == -1:
            label.config(text=f"{text_axis}: MOVING (-)", fg="green")
        else:
            label.config(text=f"{text_axis}: IDLE", fg="grey")

    def handle_keypress(self, event):
        key = event.keysym
        if key in self.key_states and not self.key_states[key]:
            self.key_states[key] = True

            if key == 'Up':
                if not self.key_states['Down']:
                    self.send_command('T', 1)
                    self.update_status('T', 1)
            elif key == 'Down':
                if not self.key_states['Up']:
                    self.send_command('T', -1)
                    self.update_status('T', -1)
            elif key == 'Left':
                if not self.key_states['Right']:
                    self.send_command('P', -1)
                    self.update_status('P', -1)
            elif key == 'Right':
                if not self.key_states['Left']:
                    self.send_command('P', 1)
                    self.update_status('P', 1)

    def handle_keyrelease(self, event):
        key = event.keysym
        if key in self.key_states:
            self.key_states[key] = False
            if key in ['Up', 'Down']:
                if self.key_states['Up']:
                    self.send_command('T', 1)
                    self.update_status('T', 1)
                elif self.key_states['Down']:
                    self.send_command('T', -1)
                    self.update_status('T', -1)
                else:
                    self.send_command('T', 0)
                    self.update_status('T', 0)

            elif key in ['Left', 'Right']:
                if self.key_states['Right']:
                    self.send_command('P', 1)
                    self.update_status('P', 1)
                elif self.key_states['Left']:
                    self.send_command('P', -1)
                    self.update_status('P', -1)
                else:
                    self.send_command('P', 0)
                    self.update_status('P', 0)

    def emergency_stop(self, event):
        self.key_states = {k: False for k in self.key_states}
        if self.is_connected:
            self.send_command('P', 0)
            self.send_command('T', 0)
            self.update_status('P', 0)
            self.update_status('T', 0)


if __name__ == "__main__":
    root = tk.Tk()
    app = PanTiltController(root)
    root.mainloop()