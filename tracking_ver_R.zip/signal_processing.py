from collections import deque

import numpy as np
from scipy.optimize import minimize_scalar

import constants

# Rolling history buffers used for temporal smoothing
thetas = deque([0.0], constants.SMOOTHING_WINDOW_LEN)  # elevation-from-horizon, rad
phis   = deque([0.0], constants.SMOOTHING_WINDOW_LEN)  # azimuth, rad


# ---------- generic signal helpers ----------

def center(signal):
    return signal - np.mean(signal)


def rms(signal):
    return np.sqrt(np.mean(signal ** 2))


def sigma(correlation_array):
    no_dc = center(correlation_array)
    var = np.sum(no_dc ** 2) / (len(no_dc) - 1)
    return np.sqrt(var)


def corr(signal1, signal2, n=constants.CORRELATION_WINDOW):
    """Time-domain normalized cross-correlation (used only by the live plot)."""
    s1 = np.asarray(signal1)
    s2 = np.asarray(signal2)
    if len(s1) != len(s2):
        raise ValueError("signal1 and signal2 must be the same length")
    cc = np.zeros(2 * n + 1)
    for lag in range(-n, n + 1):
        cc[lag + n] = np.dot(s1, np.roll(s2, lag))
    return cc / (rms(s1) * rms(s2) * len(s1))


# ---------- TDOA (Time Difference Of Arrival) ----------

def calculate_delay_fourier(signal1, signal2, interpolate=True):
    """GCC-PHAT delay estimate of signal2 vs signal1, in samples
    (positive => s2 lags s1). Parabolic peak interpolation gives sub-sample
    resolution, which matters at 16 kHz where max inter-mic delay is only
    ~4 samples for this geometry."""
    s1 = np.asarray(signal1)
    s2 = np.asarray(signal2)
    if s1.ndim != 1 or s2.ndim != 1:
        raise ValueError("Signals must be 1-D.")
    L = max(len(s1), len(s2))
    if L == 0:
        return np.nan
    s1 = np.pad(s1, (0, L - len(s1)))
    s2 = np.pad(s2, (0, L - len(s2)))

    G = np.fft.fft(s1) * np.conj(np.fft.fft(s2))
    if np.all(np.abs(G) < 1e-12):
        return np.nan
    G = G / (np.abs(G) + 1e-10)              # PHAT weighting
    cc = np.fft.fftshift(np.real(np.fft.ifft(G)))

    if not np.any(np.isfinite(cc)):
        return np.nan

    lags = np.arange(-(L // 2), L - (L // 2))
    k = int(np.argmax(cc))
    delay = float(lags[k])

    if interpolate and 1 <= k < L - 1:
        ym, y0, yp = cc[k - 1], cc[k], cc[k + 1]
        denom = ym - 2 * y0 + yp
        if denom != 0:
            delay += 0.5 * (ym - yp) / denom
    return delay


# ---------- DOA (Direction Of Arrival) ----------
#
# Far-field model. A source at azimuth phi (horizontal angle) and
# elevation alpha (above the array plane) gives a TDOA between mics i, j of
#
#     tau_ij = (R / c) * cos(alpha) * [cos(angle_j - phi) - cos(angle_i - phi)]
#
# Define
#     K        := R * cos(alpha) / c        (>= 0)
#     g_ij(phi):= cos(angle_j - phi) - cos(angle_i - phi)
#
# Then tau_ij = K * g_ij(phi). Across all pairs this is a linear LS problem
# in K once phi is known. We therefore:
#
#   1. find phi by maximizing the *signed* cosine similarity
#         <tau, g(phi)> / ||g(phi)||
#      (signed so the result is phi, not phi+pi)
#   2. solve the closed form K* = <tau, g> / <g, g>
#   3. recover elevation as alpha = arccos( clip(K* c / R, -1, 1) )
#
# This replaces the original "center-mic as reference" trick (no center mic
# on the ReSpeaker) and the M=3 harmonic Fourier fit (underdetermined for
# only 4 mics).

def _build_pairs(N):
    return [(i, j) for i in range(N) for j in range(i + 1, N)]


def _g_vector(phi, pair_indices, angles):
    return np.array([np.cos(angles[j] - phi) - np.cos(angles[i] - phi)
                     for (i, j) in pair_indices])


def estimate_doa(signals):
    """Estimate (phi, theta_elev) from a chunk of multi-channel mic signals.

    Args:
        signals: ndarray of shape (n_samples, n_mics).

    Returns:
        phi               -- azimuth, rad in [0, 2*pi)             (smoothed)
        theta_elev        -- elevation from horizon, rad in [0, pi/2] (smoothed)
        tau_pairs_seconds -- raw measured TDOA per pair, ndarray
        pair_indices      -- list of (i, j) describing tau ordering
    """
    global phis, thetas

    N = signals.shape[1]
    angles = constants.MIC_ANGLES
    R = constants.MIC_ARRAY_RADIUS
    c = constants.SPEED_OF_SOUND
    fs = constants.SAMPLE_RATE

    pair_indices = _build_pairs(N)

    # 1. measure TDOA for every mic pair (seconds)
    tau = np.zeros(len(pair_indices))
    for k, (i, j) in enumerate(pair_indices):
        d = calculate_delay_fourier(signals[:, i], signals[:, j])
        tau[k] = 0.0 if (d is None or np.isnan(d)) else d / fs

    # 2. find azimuth -- coarse grid then refined bounded search
    def neg_score(phi):
        g = _g_vector(phi, pair_indices, angles)
        gg = float(np.dot(g, g))
        if gg < 1e-15:
            return 0.0
        return -float(np.dot(tau, g)) / np.sqrt(gg)  # signed -> picks phi (not phi+pi)

    grid = np.linspace(0.0, 2 * np.pi, 72, endpoint=False)
    scores = [neg_score(p) for p in grid]
    p0 = float(grid[int(np.argmin(scores))])
    half_step = np.pi / 72
    res = minimize_scalar(neg_score,
                          bounds=(p0 - half_step, p0 + half_step),
                          method='bounded',
                          options={'xatol': 1e-7})
    phi_raw = float(res.x) % (2 * np.pi)

    # 3. recover elevation from K = R*cos(alpha)/c
    g = _g_vector(phi_raw, pair_indices, angles)
    gg = float(np.dot(g, g))
    if gg > 1e-15:
        K = float(np.dot(tau, g)) / gg
        cos_alpha = np.clip(K * c / R, -1.0, 1.0)
        theta_raw = float(np.arccos(cos_alpha))
    else:
        theta_raw = thetas[-1]

    # 4. temporal smoothing (with 2*pi-unwrap on phi)
    last_phi = phis[-1]
    phi_unwrapped = phi_raw + np.round((last_phi - phi_raw) / (2 * np.pi)) * (2 * np.pi)
    phi = constants.SMOOTHING_ALPHA * phi_unwrapped + (1 - constants.SMOOTHING_ALPHA) * last_phi
    phis.append(phi)

    last_theta = thetas[-1]
    theta = constants.SMOOTHING_ALPHA * theta_raw + (1 - constants.SMOOTHING_ALPHA) * last_theta
    thetas.append(theta)

    return phi, theta, tau, pair_indices


# ---------- legacy / experimental helpers ----------
# Not used by the live pipeline anymore but kept for reference / experimentation.

def calculate_delay(signal1, signal2, interpolate=True):
    """Time-domain cross-correlation delay (used historically; FFT version is preferred)."""
    cc = corr(signal1, signal2)
    if not interpolate:
        return np.argmax(cc) - constants.CORRELATION_WINDOW

    k = int(np.argmax(cc))
    if 1 <= k < len(cc) - 1:
        ym, y0, yp = cc[k - 1], cc[k], cc[k + 1]
        denom = 2 * (2 * y0 - yp - ym)
        delta = 0.5 * (ym - yp) / denom if denom != 0 else 0.0
    else:
        delta = 0.0
    return (k - constants.CORRELATION_WINDOW) + delta


def polynomial_lpf(data, window_size=10, poly_order=5):
    filtered = np.zeros_like(data, dtype=float)
    half = window_size // 2
    for i in range(len(data)):
        a = max(0, i - half)
        b = min(len(data), i + half + 1)
        coeffs = np.polyfit(np.arange(a, b), data[a:b], poly_order)
        filtered[i] = np.polyval(coeffs, i)
    return filtered


def pca_denoise(sig, k=1):
    sig = sig.T
    mu = sig.mean(axis=1, keepdims=True)
    xc = sig - mu
    R = xc @ xc.T / xc.shape[1]
    _, U = np.linalg.eigh(R)
    Uk = U[:, -k:]
    return ((Uk @ Uk.T) @ xc + mu).T
