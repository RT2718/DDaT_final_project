import numpy as np
from collections import deque

import keyboard
import pyaudio
import matplotlib.pyplot as plt

import signal_processing
import constants
from robotics import Robot


class MicArray:
    def __init__(self, rate=constants.SAMPLE_RATE, chunk_size=constants.CHUNK_SIZE, robot: Robot = None):
        self.pyaudio_instance = None
        self.stream = None
        self.channels = None
        self.sample_rate = rate
        self.chunk_size = chunk_size
        self.robot = robot

        # plotting state
        self.fig = None
        self.ax_corr = None
        self.ax_polar = None
        self.plot_lines = None
        self.polar_marker = None
        self.polar_trail_line = None
        self._trail = deque(maxlen=40)

    def _select_mic_device_index(self):
        """Pick the ReSpeaker USB Mic Array device index automatically."""
        print("-" * 120)
        print("Available ReSpeaker non-speaker audio devices:")

        max_channels = 0
        max_idx = None
        max_name = ''

        for i in range(self.pyaudio_instance.get_device_count()):
            dev = self.pyaudio_instance.get_device_info_by_index(i)
            name = dev['name']
            if (('ReSpeaker' in name) or ('reSpeaker' in name)) and ('Speakers' not in name):
                in_ch = dev['maxInputChannels']
                print(f'  index={i}, name={name!r}, in_channels={in_ch}')
                if in_ch > max_channels:
                    max_channels = in_ch
                    max_name = name
                    max_idx = i

        if max_idx is None:
            raise Exception(
                "Cannot find ReSpeaker input device. Is it plugged in, and have you "
                "flashed the 6-channel raw firmware (`6_channels_firmware.bin`)?"
            )

        self.channels = max_channels
        print("-" * 120)
        print("Selected device:")
        print(f'  name = {max_name!r}')
        print(f'  channels = {max_channels}')
        return max_idx

    def _setup_plot(self):
        """Two subplots in one figure: cross-correlation viewer + DOA polar plot."""
        plt.ion()
        self.fig = plt.figure(figsize=(12, 5))

        # ---- Left: cross-correlation between mics 0 and 2 (debug / sanity check) ----
        self.ax_corr = self.fig.add_subplot(1, 2, 1)
        times = [i - constants.CORRELATION_WINDOW for i in range(constants.CORRELATION_RANGE)]
        y0 = [0] * constants.CORRELATION_RANGE
        self.plot_lines = [self.ax_corr.plot(times, y0, marker='o')[0]]
        self.ax_corr.set_xlabel('lag [samples]')
        self.ax_corr.set_ylabel('correlation')

        # ---- Right: DOA polar plot ----
        # angular axis = phi (azimuth, 0..2*pi)
        # radial axis  = theta (polar from zenith, 0..pi/2)
        # so a source directly overhead -> marker at the center,
        #    a source at the horizon    -> marker at the outer ring.
        self.ax_polar = self.fig.add_subplot(1, 2, 2, projection='polar')
        self.ax_polar.set_rlim(0, np.pi / 2)
        self.ax_polar.set_rticks([np.pi / 8, np.pi / 4, 3 * np.pi / 8, np.pi / 2])
        self.ax_polar.set_yticklabels(['22.5°', '45°', '67.5°', '90°'])
        self.ax_polar.set_title('DOA   φ (angle)  ·  θ (radius)')

        # current estimate (red marker) + short trail of recent estimates (blue line)
        self.polar_marker, = self.ax_polar.plot([0], [0], 'o',
                                                markersize=14, color='red', zorder=5)
        self.polar_trail_line, = self.ax_polar.plot([], [], '-',
                                                    alpha=0.5, color='steelblue', linewidth=1)

        self.fig.tight_layout()

    def _process_audio_data(self, data):
        """Convert raw bytes into a (n_samples, NUM_CIRCULAR_MICS) array,
        keeping only the raw mic channels and DC-centering each one."""
        samples = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        n = samples.shape[0] // self.channels
        frames = samples.reshape((n, self.channels))

        idx = [c for c in constants.RESPEAKER_RAW_MIC_CHANNELS if c < self.channels]
        if len(idx) != constants.NUM_CIRCULAR_MICS:
            raise RuntimeError(
                f"Expected {constants.NUM_CIRCULAR_MICS} raw mic channels at indices "
                f"{constants.RESPEAKER_RAW_MIC_CHANNELS}, but the device opened with "
                f"only {self.channels} channels. Did you flash the 6-channel raw firmware?"
            )

        mics = frames[:, idx].copy()
        for i in range(mics.shape[1]):
            mics[:, i] = signal_processing.center(mics[:, i])
        return mics

    def _calculate_angles(self, samples_by_channel):
        phi, theta_elev, _, _ = signal_processing.estimate_doa(samples_by_channel)
        # convert elevation-from-horizon -> polar-from-zenith for downstream consumers
        theta_polar = np.pi / 2 - theta_elev
        return phi, theta_polar

    def _update_visualization(self, samples_by_channel, phi, theta):
        # --- DOA polar plot ---
        self._trail.append((phi, theta))
        self.polar_marker.set_data([phi], [theta])
        if len(self._trail) > 1:
            tp, tt = zip(*self._trail)
            self.polar_trail_line.set_data(list(tp), list(tt))
        self.ax_polar.set_title(
            f'DOA   φ={np.rad2deg(phi) % 360:5.1f}°  θ={np.rad2deg(theta):4.1f}°'
        )

        # --- correlation viewer (opposite mics on the square: 0 vs 2) ---
        a = samples_by_channel[:, 0]
        b = samples_by_channel[:, 2]
        r = signal_processing.corr(a, b)
        self.plot_lines[0].set_ydata(r)
        self.ax_corr.set_title(f"correlation mics 0 & 2   σ = {signal_processing.sigma(r):.4f}")
        self.ax_corr.relim()
        self.ax_corr.autoscale_view()

        plt.draw()
        plt.pause(0.001)

    def run(self):
        self.pyaudio_instance = pyaudio.PyAudio()
        device_index = self._select_mic_device_index()

        self.stream = self.pyaudio_instance.open(
            format=pyaudio.paInt16,
            channels=self.channels,
            rate=self.sample_rate,
            frames_per_buffer=self.chunk_size,
            input=True,
            input_device_index=device_index,
        )

        print("-" * 120)
        print("Settings:")
        print(f"  Sample rate : {self.sample_rate} Hz")
        print(f"  Chunk size  : {self.chunk_size}")
        print(f"  Total chans : {self.channels}")
        print(f"  Mic chans   : {constants.RESPEAKER_RAW_MIC_CHANNELS} ({constants.NUM_CIRCULAR_MICS} mics)")
        print(f"  Mic radius  : {constants.MIC_ARRAY_RADIUS * 1000:.1f} mm")
        print("-" * 120)
        print("Starting measurements... (press 'w' to stop)")

        self._setup_plot()

        try:
            while True:
                data = self.stream.read(self.chunk_size, exception_on_overflow=False)
                mics = self._process_audio_data(data)
                phi, theta = self._calculate_angles(mics)

                if self.robot:
                    self.robot.update(theta, phi)
                self._update_visualization(mics, phi, theta)

                if keyboard.is_pressed('w'):
                    break
        finally:
            self.stream.stop_stream()
            self.stream.close()
            self.pyaudio_instance.terminate()

        plt.pause(100)