import numpy as np
import sounddevice as sd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from scipy.optimize import minimize_scalar
import queue
from scipy.signal import butter, sosfilt, sosfilt_zi
import serial  # ### --- SERIAL ADDITION --- ###
import time

# --- 1. Global Parameters & Pre-computations ---
FS = 16000
C = 343.0
D = 0.049497
BLOCKSIZE = 4096
FFT_SIZE = BLOCKSIZE
FREQ_L = 300.0
FREQ_H = 3000.0
freq_filtering = False
whitening = False
lawson = False
butter_filter = False

FILTER_ORDER = 4
sos = butter(FILTER_ORDER, [FREQ_L, FREQ_H], btype='band', fs=FS, output='sos')
filter_state = np.tile(sosfilt_zi(sos), (4, 1, 1))
r = D / np.sqrt(2)

EMA_ALPHA = 0.2
ema_vector = None

r_mn = np.array([
    [-D / 2, -D / 2, 0],  # m = 0
    [-D / 2, D / 2, 0],  # m = 1
    [D / 2, D / 2, 0],  # m = 2
    [D / 2, -D / 2, 0]  # m = 3
])

lags = (np.arange(FFT_SIZE) - FFT_SIZE // 2) / FS
phi_mn = [(5 / 4) * np.pi, (3 / 4) * np.pi, (1 / 4) * np.pi, (7 / 4) * np.pi]


def build_pairs(N):
    return [(i, j) for i in range(N) for j in range(i + 1, N)]


pairs = build_pairs(len(r_mn))
A_matrix = np.zeros((len(pairs), 2))
tau_max_array = np.zeros(len(pairs))

for k, (i, j) in enumerate(pairs):
    diff = (r_mn[j] - r_mn[i])
    A_matrix[k, :] = diff[:2]
    if (i, j) in [(1, 3), (3, 1), (0, 2), (2, 0)]:
        tau_max_array[k] = np.sqrt(2) * D / C
    else:
        tau_max_array[k] = D / C

window = np.hanning(BLOCKSIZE).astype(np.float32)
audio_queue = queue.Queue()


def audio_callback(indata, frames, time, status):
    if status: print(f"Audio Status: {status}")
    audio_queue.put(indata.copy())


# --- 2. TDOA and DOA Engine ---
# [Your exact calculate_delay_fourier, theoretical_tau, score_phi, compute_doa remain unchanged here]
def calculate_delay_fourier(yi, yj, k):
    Yi = np.fft.rfft(yi, n=FFT_SIZE)
    Yj = np.fft.rfft(yj, n=FFT_SIZE)
    freqs = np.fft.rfftfreq(FFT_SIZE, 1 / FS)
    if freq_filtering:
        freq_mask = (freqs >= FREQ_L) & (freqs <= FREQ_H)
        Yi *= freq_mask
        Yj *= freq_mask
    G = Yi * np.conj(Yj)
    if np.all(np.abs(G) < 1e-12):
        return 0.0, 0.0, 0.0
    G_phat = G / (np.abs(G) + 1e-12)
    R = np.fft.irfft(G_phat, n=FFT_SIZE)
    R = np.fft.fftshift(R)
    max_tau = tau_max_array[k]
    valid = np.abs(lags) <= max_tau + 1 / FS
    valid_idx = np.flatnonzero(valid)
    lo_idx = int(valid_idx[0])
    hi_idx = int(valid_idx[-1])
    R_masked = np.where(valid, R, -np.inf)
    idx = int(np.argmax(R_masked))
    c1 = float(R_masked[idx])
    R_temp = R_masked.copy()
    R_temp[idx] = -np.inf
    idx2 = int(np.argmax(R_temp))
    c2 = float(R_temp[idx2])
    idx_m1 = max(idx - 1, lo_idx)
    idx_p1 = min(idx + 1, hi_idx)
    Rm1, R0, Rp1 = R[idx_m1], R[idx], R[idx_p1]
    denom = Rm1 - 2.0 * R0 + Rp1
    delta = 0.5 * (Rm1 - Rp1) / denom if abs(denom) > 1e-12 else 0.0
    idx_refined = float(np.clip(idx + delta, lo_idx, hi_idx))
    tau = (idx_refined - FFT_SIZE // 2) / FS
    if lawson:
        P_LAWSON = 1.7
        LAWSON_SEARCH_RES = 30
        shifts = np.linspace(-0.1 * max_tau, 0.1 * max_tau, LAWSON_SEARCH_RES)
        local_tau_grid = np.clip(tau + shifts, -max_tau, max_tau)
        phase_shift = np.exp(-2j * np.pi * freqs[None, :] * local_tau_grid[:, None])
        Yj_shifted = Yj[None, :] * phase_shift
        Y_diff = Yi[None, :] - Yj_shifted
        y_diff = np.fft.irfft(Y_diff, n=FFT_SIZE, axis=-1)
        Lp_norm = np.sum(np.abs(y_diff) ** P_LAWSON, axis=-1)
        best_idx = np.argmin(Lp_norm)
        tau = local_tau_grid[best_idx]
    return tau, c1, c2


def theoretical_tau(phi):
    u = np.array([np.cos(phi), np.sin(phi), 0.0])
    tau_theo = np.zeros(len(pairs))
    for k, (i, j) in enumerate(pairs):
        tau_theo[k] = r / C * (np.cos(phi - phi_mn[j]) - np.cos(phi - phi_mn[i]))
    return tau_theo


def score_phi(phi, tau_measured):
    tau_theo = theoretical_tau(phi)
    return -float(np.dot(tau_theo, tau_measured))


def compute_doa(block):
    global filter_state
    x = np.zeros((4, BLOCKSIZE), dtype=np.float32)
    x[0, :] = block[:, 4]
    x[1, :] = block[:, 3]
    x[2, :] = block[:, 2]
    x[3, :] = block[:, 1]
    if butter_filter:
        for ch in range(4):
            x[ch], filter_state[ch] = sosfilt(sos, x[ch], zi=filter_state[ch])
    x = x * window
    if whitening:
        R_x = np.cov(x) + np.eye(4) * 1e-6
        eigvals, eigvecs = np.linalg.eigh(R_x)
        eigvals = np.maximum(eigvals, 1e-10)
        W = np.diag(1.0 / np.sqrt(eigvals)) @ eigvecs.T
        x = W @ x
    tau_measured = np.zeros(len(pairs))
    c1_measured = np.zeros(len(pairs))
    c2_measured = np.zeros(len(pairs))
    for k, (i, j) in enumerate(pairs):
        t, c1, c2 = calculate_delay_fourier(x[i], x[j], k)
        tau_measured[k] = t
        c1_measured[k] = c1
        c2_measured[k] = c2
    q2 = 1.0 - np.abs((c2_measured / (c1_measured + 1e-12)))
    weights = q2
    W = np.diag(weights)
    d = tau_measured * C
    At_W_A = A_matrix.T @ W @ A_matrix
    At_W_d = A_matrix.T @ W @ d
    u_xy = np.linalg.inv(At_W_A + 1e-10 * np.eye(2)) @ At_W_d
    mag_u_xy = np.linalg.norm(u_xy)
    mag_u_xy = np.clip(mag_u_xy, 0.0, 1.0)
    theta_raw = float(np.arcsin(mag_u_xy))
    phi_raw = float(np.arctan2(u_xy[1], u_xy[0])) % (2 * np.pi)
    return phi_raw, theta_raw


# --- 3. Matplotlib 3D Polar Animation ---
plt.ion()
fig = plt.figure(figsize=(9, 8))
ax = fig.add_subplot(111, projection='polar')
ax.set_ylim(0, np.pi / 2)
ax.set_yticks([0, np.pi / 8, np.pi / 4, 3 * np.pi / 8, np.pi / 2])
ax.set_yticklabels(['$0$', r'$\pi/8$', r'$\pi/4$', r'$3\pi/8$', r'$\pi/2$'])
ax.set_title("GCC-PHAT Pairwise 3D DOA\n(Radius = Theta, Angle = Phi)")
peak_marker, = ax.plot([], [], 'ro', markersize=14, markeredgecolor='white', zorder=5)

# ### --- SERIAL GLOBAL --- ###
stm_serial = None


def update_plot(frame):
    global ema_vector, stm_serial

    block = None
    while not audio_queue.empty():
        block = audio_queue.get_nowait()

    if block is None or block.shape[0] < BLOCKSIZE:
        return peak_marker,

    raw_phi, raw_theta = compute_doa(block)

    # --- EMA FILTERING ---
    u_x = np.sin(raw_theta) * np.cos(raw_phi)
    u_y = np.sin(raw_theta) * np.sin(raw_phi)
    u_z = np.cos(raw_theta)
    current_vector = np.array([u_x, u_y, u_z])

    if ema_vector is None:
        ema_vector = current_vector
    else:
        ema_vector = (EMA_ALPHA * current_vector) + ((1.0 - EMA_ALPHA) * ema_vector)

    ema_vector /= (np.linalg.norm(ema_vector) + 1e-12)

    best_theta = np.arccos(np.clip(ema_vector[2], -1.0, 1.0))
    best_phi = np.arctan2(ema_vector[1], ema_vector[0])
    if best_phi < 0:
        best_phi += 2 * np.pi

    peak_marker.set_data([best_phi], [best_theta])

    print(f"Raw Peak: {np.rad2deg(raw_phi):.1f}째 azimuth, {np.rad2deg(raw_theta):.1f}째 elev "
          f"| Smoothed Peak: {np.rad2deg(best_phi):.1f}째, {np.rad2deg(best_theta):.1f}째")

    # ### --- SERIAL ADDITION: Transmit Data to STM32 --- ###
    if stm_serial is not None and stm_serial.is_open:
        try:
            # Format: "P:<phi>,T:<theta>\n"
            msg = f"P:{best_phi:.4f},T:{best_theta:.4f}\n"
            stm_serial.write(msg.encode('ascii'))
        except Exception as e:
            print(f"Serial write error: {e}")

    return peak_marker,


# --- 4. Main Execution ---
if __name__ == "__main__":
    # ### --- SERIAL ADDITION: Open Port --- ###
    # Change 'COM3' to whatever your setup uses (e.g., 'COM4', '/dev/ttyUSB0')
    try:
        stm_serial = serial.Serial('COM3', baudrate=115200, timeout=0)
        print("Successfully opened serial connection to STM32.")
    except Exception as e:
        print(f"Warning: Could not open STM32 serial port. Running without motor control.\nError: {e}")

    dev_idx = None
    for i, dev in enumerate(sd.query_devices()):
        if 'respeaker' in dev['name'].lower() and dev['max_input_channels'] >= 6:
            dev_idx = i
            break

    if dev_idx is None:
        print("Warning: ReSpeaker not found. Falling back to default input.")

    print(f"Starting Pairwise GCC-PHAT stream on device {dev_idx}. Close window to stop.")

    stream = sd.InputStream(device=dev_idx, samplerate=FS, channels=6 if dev_idx is not None else 1,
                            blocksize=BLOCKSIZE, dtype='float32', callback=audio_callback)

    with stream:
        ani = FuncAnimation(fig, update_plot, interval=50, blit=True, cache_frame_data=False)
        plt.show(block=True)

    # ### --- SERIAL ADDITION: Clean exit --- ###
    if stm_serial is not None and stm_serial.is_open:
        stm_serial.close()