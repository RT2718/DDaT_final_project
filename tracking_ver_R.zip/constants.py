import numpy as np

# --- Physical / acoustic constants ---
SPEED_OF_SOUND = 343  # m/s

# --- Audio interface settings (ReSpeaker USB Mic Array) ---
# After flashing the 6-channels raw firmware (`6_channels_firmware.bin`),
# the device exposes 6 input channels:
#   ch 0   -> processed/AEC mono       (NOT used here)
#   ch 1-4 -> 4 raw microphones        (USED)
#   ch 5   -> playback reference       (NOT used here)
SAMPLE_RATE = 16000                       # ReSpeaker default; the device will not run at 48 kHz
CHUNK_SIZE = 4000                         # ~250 ms windows (≈ original 208 ms latency)
RESPEAKER_RAW_MIC_CHANNELS = [1, 2, 3, 4] # which channels of the 6-ch stream are raw mics

# --- Cross-correlation viewer (only used by the live correlation plot) ---
CORRELATION_WINDOW = 10
CORRELATION_RANGE = 2 * CORRELATION_WINDOW + 1

# --- Microphone array geometry (ReSpeaker = 4 mics on a circle, no center mic) ---
# IMPORTANT: measure your specific board. ~46 mm is typical for the v2 / USB Mic Array.
# Take a caliper to the centers of two opposite mics; that distance is 2*R.
MIC_ARRAY_RADIUS = 0.0463                 # m -- adjust to your physical board
NUM_CIRCULAR_MICS = 4
MIC_ANGLES = np.linspace(0, 2 * np.pi, NUM_CIRCULAR_MICS, endpoint=False)  # [0, π/2, π, 3π/2]

# --- Smoothing of the (phi, theta) estimates ---
SMOOTHING_WINDOW_LEN = 50
SMOOTHING_ALPHA = 0.7

# --- Stepper motor on the robot azimuth axis ---
NUM_STEPS_PHI_ANGLE = 6400

# --- Misc ---
SHOW_PROBABILITY = False
