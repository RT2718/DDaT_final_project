/**
  ******************************************************************************
  * @file    main.c
  * @brief   Acoustic Tracking Motor Control (Goto Logic with Robust RTOS-style ISR)
  ******************************************************************************
  */

#include "main.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MyFlagInterruptHandler(void);
static void MX_USART2_UART_Init(void);
void Error_Handler(uint16_t error);
void Process_Motor_Control(void);

UART_HandleTypeDef huart2;

/* --- Mechanical Conversions --- */
const float STEPS_PER_DEG_PAN = 3345.0f / 360.0f;
const float STEPS_PER_DEG_TILT = 16576.0f / 360.0f;

const float RAD_PER_STEP_PAN = (M_PI / 180.0f) / (3345.0f / 360.0f);
const float RAD_PER_STEP_TILT = (M_PI / 180.0f) / (16576.0f / 360.0f);

// 5 degree deadband in radians
const float DEADBAND_RAD = 5.0f * (M_PI / 180.0f);

/* --- Communication Globals --- */
volatile float target_alpha = 0.0f; // Pan Target (from Python 'phi')
volatile float target_beta = 0.0f;  // Tilt Target (from Python 'theta')
volatile uint32_t last_msg_time = 0;

/* --- UART Double Buffering (Ping-Pong) Variables --- */
volatile uint8_t string_ready = 0;
volatile uint8_t write_idx = 0;  // ISR writes to this index
char rx_buf[2][32];              // Two distinct buffers
uint8_t rx_byte;
uint8_t rx_index = 0;


int main(void)
{
    HAL_Init();
    SystemClock_Config();

    /* Initialize Serial Port (USB) */
    MX_USART2_UART_Init();

    /* 1. Initialize Motors (0 = Pan, 2 = Tilt) */
    BSP_MotorControl_SetNbDevices(BSP_MOTOR_CONTROL_BOARD_ID_L6474, 3);
    BSP_MotorControl_Init(BSP_MOTOR_CONTROL_BOARD_ID_L6474, NULL);
    BSP_MotorControl_Init(BSP_MOTOR_CONTROL_BOARD_ID_L6474, NULL);
    BSP_MotorControl_Init(BSP_MOTOR_CONTROL_BOARD_ID_L6474, NULL);

    BSP_MotorControl_AttachFlagInterrupt(MyFlagInterruptHandler);
    BSP_MotorControl_AttachErrorHandler(Error_Handler);

    /* Base Configurations */
    BSP_MotorControl_SetMinSpeed(0, 320);
    BSP_MotorControl_SetMaxSpeed(0, 3000);
    BSP_MotorControl_SetAcceleration(0, 5000);
    BSP_MotorControl_SetDeceleration(0, 5000);

    BSP_MotorControl_SetMinSpeed(2, 500);
    BSP_MotorControl_SetMaxSpeed(2, 3000);
    BSP_MotorControl_SetAcceleration(2, 6000);
    BSP_MotorControl_SetDeceleration(2, 6000);

    last_msg_time = HAL_GetTick();

    // Start listening for UART data
    if (HAL_UART_Receive_IT(&huart2, &rx_byte, 1) != HAL_OK) {
        Error_Handler(0);
    }

    while (1)
    {
        // --- ISR-SAFE DOUBLE BUFFER PARSING ---
        if (string_ready)
        {
            __disable_irq();
            string_ready = 0;
            uint8_t read_idx = 1 - write_idx; // Read from the buffer the ISR is NOT using
            __enable_irq();

            float temp_alpha, temp_beta;

            // Strict Validation (Requires exactly two valid floats separated by a comma)
            if (sscanf(rx_buf[read_idx], "P:%f,T:%f", &temp_alpha, &temp_beta) == 2)
            {
            	float diff_a = temp_alpha - target_alpha;
            	float diff_b = temp_beta - target_beta;
            	if (diff_a > M_PI) diff_a -= 2.0f * M_PI;
            	if (diff_a < -M_PI) diff_a += 2.0f * M_PI;
            	if (fabs(diff_a) > DEADBAND_RAD){
            		target_alpha = temp_alpha;
            	}

            	if (fabs(diff_b) > DEADBAND_RAD){
            		target_beta = temp_beta;
            	}

                last_msg_time = HAL_GetTick(); // Reset heartbeat
            }
        }

        // Continuously process motor movements toward target
        Process_Motor_Control();

        // Small delay to prevent tight loop lockup
        HAL_Delay(5);
    }
}

/* --- Motor Processing Logic --- */
void Process_Motor_Control(void)
{
    // 1. Get current physical step positions
    int32_t raw_pan_steps = BSP_MotorControl_GetPosition(0);
    int32_t raw_tilt_steps = BSP_MotorControl_GetPosition(2);

    // 2. Convert to radians
    float a_current = (float)raw_pan_steps * RAD_PER_STEP_PAN;
    float b_raw_current = (float)raw_tilt_steps * RAD_PER_STEP_TILT;
    float b_current = -b_raw_current; // Negated per your setup

    // 3. The infinite unwind wrap-around fix for Pan
    a_current = fmodf(a_current, 2.0f * M_PI);
    if (a_current > M_PI)  a_current -= 2.0f * M_PI;
    if (a_current < -M_PI) a_current += 2.0f * M_PI;

    // 4. Stop if python disconnects
    if ((HAL_GetTick() - last_msg_time) > 1500) {
        target_alpha = a_current;
        target_beta = b_current;
        BSP_MotorControl_SoftStop(0);
        BSP_MotorControl_SoftStop(2);
        return;
    }

    // 5. Calculate shortest-path errors
    float error_a = target_alpha - a_current;
    float error_b = target_beta - b_current;

    // Wrap the error so the motor takes the shortest route (-pi to pi)
    if (error_a > M_PI)  error_a -= 2.0f * M_PI;
    if (error_a < -M_PI) error_a += 2.0f * M_PI;

    int32_t step_offset_pan = (int32_t)(error_a / RAD_PER_STEP_PAN);
    BSP_MotorControl_GoTo(0, raw_pan_steps + step_offset_pan);
    int32_t step_offset_tilt = (int32_t)(-error_b / RAD_PER_STEP_TILT);
    BSP_MotorControl_GoTo(2, raw_tilt_steps + step_offset_tilt);

    /*
    // 6. Act on Pan Motor (Azimuth)
    if (fabsf(error_a) > DEADBAND_RAD) {
    	int32_t step_offset_pan = (int32_t)(error_a / RAD_PER_STEP_PAN);
        BSP_MotorControl_GoTo(0, raw_pan_steps + step_offset_pan);
    } else {
        BSP_MotorControl_SoftStop(0);
    }

    // 7. Act on Tilt Motor (Elevation)
    if (fabsf(error_b) > DEADBAND_RAD) {
        int32_t step_offset_tilt = (int32_t)(-error_b / RAD_PER_STEP_TILT);
        BSP_MotorControl_GoTo(2, raw_tilt_steps + step_offset_tilt);
    } else {
        BSP_MotorControl_SoftStop(2);
    }
    */
}

/* --- UART Interrupt Callback (Double-Buffered, Race-Free, with Overflow Recovery) --- */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // Static flag to track if we are currently discarding a corrupted/oversized stream
    static uint8_t overflow_flag = 0;

    if (rx_byte == '\n') {
        if (overflow_flag) {
            // We finally found a newline, but the message before it was oversized/corrupted.
            // Discard the garbage, clear the flag, and silently resynchronize.
            overflow_flag = 0;
            rx_index = 0;
        } else {
            // 1. Terminate the valid string
            rx_buf[write_idx][rx_index] = '\0';

            // 2. EXPLICIT OWNERSHIP HANDOFF: Flip the index FIRST
            write_idx = 1 - write_idx;
            rx_index = 0;

            // 3. Raise the flag LAST. The main loop will now read (1 - write_idx),
            // which safely points to the buffer we just finished filling.
            string_ready = 1;
        }
    } else {
        if (rx_index < 31) {
            // Normal operation: store byte
            rx_buf[write_idx][rx_index++] = rx_byte;
        } else {
            // Memory safety hit: The string is too long. Stop recording and enter discard mode.
            overflow_flag = 1;
        }
    }

    // Safely re-arm with checked return value
    if (HAL_UART_Receive_IT(huart, &rx_byte, 1) != HAL_OK) {
        // Force state machine reset if hardware locks up during re-arm
        huart->RxState = HAL_UART_STATE_READY;
        HAL_UART_Receive_IT(huart, &rx_byte, 1);
    }
}

/* --- UART Error Callback (Catches Overruns and Prevents Freezing) --- */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        __HAL_UART_CLEAR_OREFLAG(huart);
        __HAL_UART_CLEAR_NEFLAG(huart);
        __HAL_UART_CLEAR_FEFLAG(huart);

        // Hard reset Rx state and buffer index to prevent trailing garbage
        rx_index = 0;
        huart->RxState = HAL_UART_STATE_READY;
        HAL_UART_Receive_IT(huart, &rx_byte, 1);
    }
}

/* --- Required BSP Interrupt/Error Handlers --- */
void MyFlagInterruptHandler(void)
{
    BSP_MotorControl_CmdGetStatus(0);
    BSP_MotorControl_CmdGetStatus(1);
    BSP_MotorControl_CmdGetStatus(2);
}

void Error_Handler(uint16_t error)
{
    while(1) { } // Trap errors
}

/* --- Hardware Initialization Functions --- */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK) {
      Error_Handler(0);
  }
}

void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(huart->Instance == USART2)
  {
    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* This turns the interrupt on! */
    HAL_NVIC_SetPriority(USART2_IRQn, 0, 1);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{
  if(huart->Instance == USART2)
  {
    __HAL_RCC_USART2_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2|GPIO_PIN_3);
    HAL_NVIC_DisableIRQ(USART2_IRQn);
  }
}

/* Provide empty system clock config to satisfy linker if not generated */
__weak void SystemClock_Config(void) {}

/* --- UART/DMA STUBS (Prevents Linker Errors) --- */
HAL_StatusTypeDef HAL_DMA_Abort(DMA_HandleTypeDef *hdma) { return HAL_OK; }
HAL_StatusTypeDef HAL_DMA_Abort_IT(DMA_HandleTypeDef *hdma) { return HAL_OK; }

/* --- SYSTEM CALL STUBS (Prevents libc_nano errors) --- */
#include <sys/stat.h>
__attribute__((weak)) int _close(int file) { return -1; }
__attribute__((weak)) int _fstat(int file, struct stat *st) { st->st_mode = S_IFCHR; return 0; }
__attribute__((weak)) int _isatty(int file) { return 1; }
__attribute__((weak)) int _lseek(int file, int ptr, int dir) { return 0; }
__attribute__((weak)) int _read(int file, char *ptr, int len) { return 0; }
__attribute__((weak)) int _write(int file, char *ptr, int len) { return len; }
__attribute__((weak)) int _kill(int pid, int sig) { return -1; }
__attribute__((weak)) int _getpid(void) { return 1; }

__attribute__((weak)) void *_sbrk(int incr) {
    extern char _end;
    static char *heap_end = 0;
    char *prev_heap_end;
    if (heap_end == 0) heap_end = &_end;
    prev_heap_end = heap_end;
    heap_end += incr;
    return (void *)prev_heap_end;
}
