import time
import numpy as np
from collections import deque

import keyboard
import pyaudio
import matplotlib.pyplot as plt

import signal_processing
import constants
from robotics import Robot


class MicArray:
    def __init__(self, rate=constants.SAMPLE_RATE, chunk_size=constants.CHUNK_SIZE, robot: Robot = None):
        self.pyaudio_instance = None
        self.stream = None
        self.channels = None
        self.sample_rate = rate
        self.chunk_size = chunk_size
        self.robot = robot

        # plotting state
        self.fig = None
        self.ax_phi = None
        self.ax_theta = None
        self.line_phi = None
        self.line_theta = None
        self.trajectory_mode = None

        # History trackers for the error graphs
        self.frame_indices = []
        self.phi_errors = []
        self.theta_errors = []

    def _select_mic_device_index(self):
        """Pick the ReSpeaker USB Mic Array device index automatically."""
        print("-" * 120)
        print("Available ReSpeaker non-speaker audio devices:")

        max_channels = 0
        max_idx = None
        max_name = ''

        for i in range(self.pyaudio_instance.get_device_count()):
            dev = self.pyaudio_instance.get_device_info_by_index(i)
            name = dev['name']
            if (('ReSpeaker' in name) or ('reSpeaker' in name)) and ('Speakers' not in name):
                in_ch = dev['maxInputChannels']
                print(f'  index={i}, name={name!r}, in_ch={in_ch}')
                if in_ch > max_channels:
                    max_channels = in_ch
                    max_name = name
                    max_idx = i

        if max_idx is None:
            raise Exception("Cannot find ReSpeaker input device.")

        self.channels = max_channels
        print("-" * 120)
        print("Selected device:")
        print(f'  name = {max_name!r}')
        print(f'  channels = {max_channels}')
        return max_idx

    def _setup_plot(self, trajectory_name="Live"):
        """Sets up single or double subplots dynamically with poster-ready formatting."""
        self.trajectory_mode = trajectory_name
        plt.ion()

        # Set global Matplotlib parameters for high-visibility poster text
        plt.rcParams.update({
            'font.size': 14,
            'axes.labelsize': 16,
            'axes.titlesize': 18,
            'xtick.labelsize': 14,
            'ytick.labelsize': 14
        })

        self.fig = plt.figure(figsize=(10, 8))
        self.fig.suptitle(f"DOA Tracking Error - Trajectory: {trajectory_name.capitalize()}",
                          fontsize=22, fontweight='bold')

        if trajectory_name == 'circle':
            # ONLY Plot Phi
            self.ax_phi = self.fig.add_subplot(1, 1, 1)
            self.ax_phi.set_title('Error in Azimuth (Phi) [Detected - Target]')
            self.ax_phi.set_xlabel('Frame Number')
            self.ax_phi.set_ylabel('Error [degrees]')
            self.line_phi, = self.ax_phi.plot([], [], 'b-', linewidth=3)
            self.ax_phi.grid(True)

        elif trajectory_name == 'arc':
            # ONLY Plot Theta
            self.ax_theta = self.fig.add_subplot(1, 1, 1)
            self.ax_theta.set_title('Error in Polar Angle (Theta) [Detected - Target]')
            self.ax_theta.set_xlabel('Frame Number')
            self.ax_theta.set_ylabel('Error [degrees]')
            self.line_theta, = self.ax_theta.plot([], [], 'r-', linewidth=3)
            self.ax_theta.grid(True)

        else:
            # Spiral or Live Audio gets both plots stacked
            self.ax_phi = self.fig.add_subplot(2, 1, 1)
            self.ax_phi.set_title('Error in Azimuth (Phi) [Detected - Target]')
            self.ax_phi.set_xlabel('Frame Number')
            self.ax_phi.set_ylabel('Error [degrees]')
            self.line_phi, = self.ax_phi.plot([], [], 'b-', linewidth=2.5)
            self.ax_phi.grid(True)

            self.ax_theta = self.fig.add_subplot(2, 1, 2)
            self.ax_theta.set_title('Error in Polar Angle (Theta) [Detected - Target]')
            self.ax_theta.set_xlabel('Frame Number')
            self.ax_theta.set_ylabel('Error [degrees]')
            self.line_theta, = self.ax_theta.plot([], [], 'r-', linewidth=2.5)
            self.ax_theta.grid(True)

        self.fig.tight_layout(rect=[0, 0.03, 1, 0.95])  # Leave room for the main title

    def _process_audio_data(self, data):
        """Convert raw bytes into a (n_samples, NUM_CIRCULAR_MICS) array."""
        samples = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        n = samples.shape[0] // self.channels
        frames = samples.reshape((n, self.channels))

        idx = [c for c in constants.RESPEAKER_RAW_MIC_CHANNELS if c < self.channels]
        mics = frames[:, idx].copy()
        for i in range(mics.shape[1]):
            mics[:, i] = signal_processing.center(mics[:, i])
        return mics

    def _calculate_angles(self, samples_by_channel):
        phi, theta_elev, _, _ = signal_processing.estimate_doa(samples_by_channel)
        theta_polar = np.pi / 2 - theta_elev
        return phi, theta_polar

    def _update_visualization(self, samples_by_channel, phi, theta, frame_count, sim_target=None):
        if sim_target:
            t_phi, t_theta = sim_target

            # Calculate error (Estimated - Target)
            err_phi = (phi - t_phi + np.pi) % (2 * np.pi) - np.pi
            err_theta = theta - t_theta

            # Append to history
            self.phi_errors.append(np.rad2deg(err_phi))
            self.theta_errors.append(np.rad2deg(err_theta))
            self.frame_indices.append(frame_count)

            # Update dynamically only if the graph axis actually exists
            if self.ax_phi is not None:
                self.line_phi.set_data(self.frame_indices, self.phi_errors)
                self.ax_phi.relim()
                self.ax_phi.autoscale_view()

            if self.ax_theta is not None:
                self.line_theta.set_data(self.frame_indices, self.theta_errors)
                self.ax_theta.relim()
                self.ax_theta.autoscale_view()

            plt.draw()
            plt.pause(0.001)
        else:
            # Fallback output if there's no target to compare against
            print(f"Tracking DOA - φ={np.rad2deg(phi) % 360:5.1f}°  θ={np.rad2deg(theta):4.1f}°")
            plt.pause(0.001)

    def _generate_synthetic_block(self, phi, theta_elev, noise_level=0.1):
        """Generates a raw, noisy audio block mathematically perfectly delayed for your specific mic array."""
        base_audio = np.random.randn(self.chunk_size).astype(np.float32)
        base_fft = np.fft.rfft(base_audio)
        freqs = np.fft.rfftfreq(self.chunk_size, 1 / self.sample_rate)

        u = np.array([
            np.cos(phi) * np.cos(theta_elev),
            np.sin(phi) * np.cos(theta_elev),
            np.sin(theta_elev)
        ])

        N = constants.NUM_CIRCULAR_MICS
        simulated_mics = np.zeros((self.chunk_size, N), dtype=np.float32)

        R = constants.MIC_ARRAY_RADIUS
        C = constants.SPEED_OF_SOUND

        for m in range(N):
            # Calculate physical coordinate of this specific mic based on constants.py
            angle = constants.MIC_ANGLES[m]
            r_m = np.array([R * np.cos(angle), R * np.sin(angle), 0.0])

            # Apply perfect delay
            tau = -np.dot(r_m, u) / C
            phase_shift = np.exp(-1j * 2 * np.pi * freqs * tau)
            shifted_fft = base_fft * phase_shift

            # Convert to time domain and add noise
            mic_audio = np.fft.irfft(shifted_fft, n=self.chunk_size)
            mic_audio += noise_level * np.random.randn(self.chunk_size)

            # Center the signal just like _process_audio_data does
            simulated_mics[:, m] = signal_processing.center(mic_audio)

        return simulated_mics

    def _print_and_plot_statistics(self):
        """Calculates and displays performance metrics at the end of a simulation cycle."""
        props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray')

        print("\n" + "=" * 50)
        print("          DOA TRACKING ERROR STATISTICS")
        print("=" * 50)

        # Process Phi if the graph exists
        if self.ax_phi is not None and self.phi_errors:
            phi_err = np.array(self.phi_errors)
            stats_phi = {
                'Mean': np.mean(phi_err),
                'MAE': np.mean(np.abs(phi_err)),
                'RMSE': np.sqrt(np.mean(phi_err ** 2)),
                'Std Dev': np.std(phi_err),
                'Max Abs': np.max(np.abs(phi_err))
            }
            print("--- Azimuth (Phi) ---")
            for k, v in stats_phi.items():
                print(f"  {k + ':':<18} {v:>8.3f}°")

            stat_text_phi = (f"RMSE: {stats_phi['RMSE']:.2f}°\n"
                             f"MAE: {stats_phi['MAE']:.2f}°\n"
                             f"Max: {stats_phi['Max Abs']:.2f}°")

            self.ax_phi.text(0.01, 0.95, stat_text_phi, transform=self.ax_phi.transAxes,
                             verticalalignment='top', bbox=props, fontsize=14)

        # Process Theta if the graph exists
        if self.ax_theta is not None and self.theta_errors:
            theta_err = np.array(self.theta_errors)
            stats_theta = {
                'Mean': np.mean(theta_err),
                'MAE': np.mean(np.abs(theta_err)),
                'RMSE': np.sqrt(np.mean(theta_err ** 2)),
                'Std Dev': np.std(theta_err),
                'Max Abs': np.max(np.abs(theta_err))
            }
            print("\n--- Polar (Theta) ---")
            for k, v in stats_theta.items():
                print(f"  {k + ':':<18} {v:>8.3f}°")

            stat_text_theta = (f"RMSE: {stats_theta['RMSE']:.2f}°\n"
                               f"MAE: {stats_theta['MAE']:.2f}°\n"
                               f"Max: {stats_theta['Max Abs']:.2f}°")

            self.ax_theta.text(0.01, 0.95, stat_text_theta, transform=self.ax_theta.transAxes,
                               verticalalignment='top', bbox=props, fontsize=14)

        print("=" * 50 + "\n")
        plt.draw()

    def run(self, simulate=False, trajectory='circle'):
        # Determine the length of one complete cycle based on the math in the simulation
        if simulate:
            if trajectory == 'circle':
                cycle_frames = 50
            elif trajectory == 'arc':
                cycle_frames = int(20 * 2 * np.pi)  # ~125 frames to complete a sine wave
            elif trajectory == 'spiral':
                cycle_frames = int(50 * 2 * np.pi)  # ~314 frames to complete the slowest sine wave
            else:
                cycle_frames = 100
        else:
            cycle_frames = float('inf')

        # --- 1. SETUP PHASE ---
        if not simulate:
            self.pyaudio_instance = pyaudio.PyAudio()
            device_index = self._select_mic_device_index()
            self.stream = self.pyaudio_instance.open(
                format=pyaudio.paInt16, channels=self.channels,
                rate=self.sample_rate, frames_per_buffer=self.chunk_size,
                input=True, input_device_index=device_index,
            )
            print("Starting live audio measurements... (press 'w' to stop)")
            self._setup_plot(trajectory_name="Live Audio")
        else:
            print("-" * 120)
            print(f"Starting VIRTUAL Simulation Mode (Trajectory: {trajectory})...")
            print(f"Simulation will automatically stop after 1 cycle ({cycle_frames} frames).")
            print("Press 'w' in the terminal to stop early.")
            print("-" * 120)
            self._setup_plot(trajectory_name=trajectory)

        frame_count = 0

        # --- 2. EXECUTION LOOP ---
        try:
            while True:
                # Stop if we have completed exactly one cycle
                if simulate and frame_count >= cycle_frames:
                    print(f"\n[!] Completed one full '{trajectory}' cycle.")
                    self._print_and_plot_statistics()
                    print("Simulation paused. Close the graph window to exit.")
                    break

                sim_target = None

                # GRAB DATA (Hardware or Software)
                if not simulate:
                    data = self.stream.read(self.chunk_size, exception_on_overflow=False)
                    mics = self._process_audio_data(data)
                else:
                    # Trajectory Math
                    t = frame_count
                    if trajectory == 'circle':
                        sim_phi = (t / 50.0) * (2 * np.pi) % (2 * np.pi)
                        sim_theta_elev = np.pi / 4  # Constant 45 deg elevation
                    elif trajectory == 'arc':
                        sim_phi = np.pi / 2
                        sim_theta_elev = (np.sin(t / 20) + 1) / 2 * (np.pi / 2)
                    elif trajectory == 'spiral':
                        sim_phi = (t / 20.0) * (2 * np.pi)
                        sim_theta_elev = (np.sin(t / 50) + 1) / 2 * (np.pi / 2)
                    else:  # Static point
                        sim_phi, sim_theta_elev = np.pi / 4, np.pi / 4

                    mics = self._generate_synthetic_block(sim_phi, sim_theta_elev, noise_level=0.1)
                    sim_target = (sim_phi, np.pi / 2 - sim_theta_elev)  # Save for plotting
                    time.sleep(self.chunk_size / self.sample_rate)  # Mimic physical processing delay

                # RUN THE DOA ALGORITHM
                phi, theta = self._calculate_angles(mics)

                if self.robot:
                    self.robot.update(theta, phi)

                self._update_visualization(mics, phi, theta, frame_count, sim_target=sim_target)

                frame_count += 1
                if keyboard.is_pressed('w'):
                    if simulate:
                        print("\n[!] Simulation stopped early.")
                        self._print_and_plot_statistics()
                    break
        finally:
            if not simulate:
                self.stream.stop_stream()
                self.stream.close()
                self.pyaudio_instance.terminate()

            # Turn off interactive mode and block script execution until the user manually closes the graph
            if self.fig and plt.fignum_exists(self.fig.number):
                plt.ioff()
                plt.show()